convert -resize 512x512 icon.jpg icon.jpg

convert -resize 512x512 icon.jpeg icon.jpg

convert -resize 512x512 logo.jpg icon.jpg

convert -resize 512x512 logo.png icon.jpg

convert -resize 512x512 1.jpg 1.jpg

convert -resize 512x512 1.png 1.png

convert -resize 512x512 1.jpeg 1.jpg

convert -resize 512x512 1.jpg 1.jpg

convert -resize 512x512 1.png 1.png

convert -resize 512x512 1.jpeg 1.jpg

convert -resize 512x512 1.jpg 1.jpg

convert -resize 512x512 1.png 1.png

convert -resize 512x512 1.jpeg 1.jpg

convert -resize 1280x720 fanart.jpg fanart.jpg

convert -resize 1280x720 fanart.jpeg fanart.jpg

convert -resize 1280x720 fanart.png fanart.jpg

read